import { useEffect, useRef, useState } from "react";

type NeuralPoint = {
  x: number; y: number; z: number;
  globeX: number; globeY: number; globeZ: number; land: boolean;
  scatterX: number; scatterY: number; scatterZ: number;
  tunnelX: number; tunnelY: number; tunnelZ: number;
  size: number; color: string; phase: number; outline: boolean;
};
type Synapse = { x: number; y: number; z: number; radius: number; phase: number; color: string };
const TAU = Math.PI * 2;
const COLORS = ["#a37bff", "#e7bd64", "#72d7d1", "#f2efff", "#705cee"];
const CONTINENTS: Array<Array<[number, number]>> = [
  [[-168,68],[-145,72],[-126,62],[-123,48],[-115,32],[-105,24],[-96,17],[-86,20],[-81,26],[-80,34],[-74,42],[-62,49],[-57,54],[-63,61],[-80,70],[-98,76],[-120,72],[-145,60]],
  [[-81,12],[-74,10],[-64,10],[-53,5],[-44,-3],[-35,-7],[-37,-16],[-42,-23],[-49,-30],[-55,-36],[-61,-43],[-67,-55],[-73,-51],[-75,-40],[-72,-27],[-76,-14],[-81,-4]],
  [[-10,36],[-6,43],[2,44],[8,48],[13,54],[9,57],[17,61],[24,69],[31,70],[40,62],[47,57],[40,49],[31,46],[26,39],[17,41],[10,37],[2,36]],
  [[-17,34],[-8,36],[8,37],[21,33],[31,31],[34,24],[43,13],[51,11],[44,0],[40,-11],[35,-22],[28,-34],[18,-35],[11,-27],[8,-5],[2,5],[-8,5],[-16,14]],
  [[28,41],[39,42],[47,49],[57,54],[69,61],[88,68],[110,72],[135,67],[160,60],[175,52],[161,48],[146,44],[136,35],[125,39],[117,24],[110,19],[105,9],[99,4],[97,19],[90,22],[84,9],[77,7],[72,20],[62,25],[54,28],[47,32],[38,35]],
  [[112,-13],[127,-12],[140,-12],[151,-22],[153,-33],[144,-39],[132,-34],[119,-35],[113,-26]],
  [[-73,60],[-58,61],[-44,66],[-29,74],[-21,82],[-46,83],[-63,77]],
  [[-8,50],[1,51],[2,58],[-4,59],[-8,55]],
];

function clamp(value: number, min = 0, max = 1) { return Math.min(max, Math.max(min, value)); }
function smoothstep(min: number, max: number, value: number) { const t = clamp((value - min) / (max - min)); return t * t * (3 - 2 * t); }
function isLand(longitude: number, latitude: number) {
  return CONTINENTS.some((polygon) => {
    let inside = false;
    for (let index = 0, previous = polygon.length - 1; index < polygon.length; previous = index++) {
      const [ax, ay] = polygon[index], [bx, by] = polygon[previous];
      if ((ay > latitude) !== (by > latitude) && longitude < (bx - ax) * (latitude - ay) / (by - ay) + ax) inside = !inside;
    }
    return inside;
  });
}

function createPoints(count: number): NeuralPoint[] {
  let seed = 928472;
  const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  return Array.from({ length: count }, (_, index) => {
    const longitude = random() * TAU, latitude = Math.acos(2 * random() - 1), shell = Math.pow(random(), .24);
    let x = Math.cos(longitude) * Math.sin(latitude) * 1.22 * shell;
    let y = Math.cos(latitude) * .83 * shell;
    let z = Math.sin(longitude) * Math.sin(latitude) * .74 * shell;
    x += Math.sin(x * 12 + y * 7) * .026;
    y += Math.sin(x * 9 - z * 8) * .034;
    y -= Math.max(0, -x - .73) * .18;
    if (index % 23 === 0) { x = .12 + (random() - .5) * .15; y = .72 + random() * .38; z = (random() - .5) * .16; }
    let globeLongitude = 0, globeLatitude = 0, land = false;
    const preferLand = index % 5 !== 0;
    for (let attempt = 0; attempt < 42; attempt++) {
      globeLongitude = random() * 360 - 180;
      globeLatitude = Math.asin(random() * 2 - 1) * 180 / Math.PI;
      land = isLand(globeLongitude, globeLatitude);
      if (land === preferLand) break;
    }
    const globeLon = globeLongitude * Math.PI / 180, globeLat = globeLatitude * Math.PI / 180;
    const globeX = Math.sin(globeLon) * Math.cos(globeLat) * 1.08;
    const globeY = -Math.sin(globeLat) * 1.08;
    const globeZ = Math.cos(globeLon) * Math.cos(globeLat) * 1.08;
    const tunnelAngle = random() * TAU, tunnelRadius = .26 + Math.pow(random(), .55) * 2.8;
    return { x, y, z, globeX, globeY, globeZ, land, scatterX: (random() - .5) * 2.5, scatterY: (random() - .5) * 2, scatterZ: (random() - .5) * 2, tunnelX: Math.cos(tunnelAngle) * tunnelRadius, tunnelY: Math.sin(tunnelAngle) * tunnelRadius * .72, tunnelZ: random() * 10 - 1, size: random() * 1.6 + .55, color: COLORS[index % COLORS.length], phase: random() * TAU, outline: index % 4 !== 0 };
  });
}

function createSynapses(count: number): Synapse[] {
  return Array.from({ length: count }, (_, index) => {
    const angle = index * 2.39996323, radius = .38 + Math.sqrt(index / count) * 2.7;
    return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius * .67, z: ((index * 1.731) % 6) - 1, radius: 3 + (index % 5) * 1.3, phase: index * 1.37, color: COLORS[index % 3] };
  });
}

function NeuralCanvas({ progress }: { progress: React.RefObject<number> }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const points = createPoints(window.innerWidth < 760 ? 1900 : 4300), synapses = createSynapses(78);
    let width = 0, height = 0, frame = 0, pointerX = 0, pointerY = 0, smoothX = 0, smoothY = 0;
    const resize = () => {
      width = window.innerWidth; height = window.innerHeight;
      const ratio = Math.min(window.devicePixelRatio || 1, 1.8);
      canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio);
      canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
    };
    const move = (event: PointerEvent) => { pointerX = (event.clientX / width - .5) * 2; pointerY = (event.clientY / height - .5) * 2; };
    const render = (now: number) => {
      const time = reducedMotion.matches ? 0 : now * .00032;
      const position = progress.current, globeMix = smoothstep(.18, .48, position), interior = smoothstep(.63, .9, position), mobile = width < 760;
      const globeVisibility = globeMix * (1 - interior), dissolve = Math.sin(Math.PI * globeMix) * (1 - interior);
      smoothX += (pointerX - smoothX) * .032; smoothY += (pointerY - smoothY) * .032;
      context.fillStyle = "#07070b"; context.fillRect(0, 0, width, height);
      const centerX = width * (mobile ? .52 : .69 - interior * .17), centerY = height * (mobile ? .43 : .49), baseScale = Math.min(width * (mobile ? .54 : .34), height * .47);
      const backgroundGlow = context.createRadialGradient(centerX, centerY, baseScale * .08, centerX, centerY, baseScale * (1.45 + interior));
      backgroundGlow.addColorStop(0, `rgba(103,75,196,${.085 + interior * .06})`); backgroundGlow.addColorStop(.53, `rgba(47,32,91,${.06 + interior * .025})`); backgroundGlow.addColorStop(1, "rgba(7,7,11,0)");
      context.fillStyle = backgroundGlow; context.fillRect(0, 0, width, height);
      if (globeMix < .83) {
        context.globalAlpha = (1 - globeMix) * .23;
        for (let band = 0; band < 11; band++) {
          const row = (band - 5) * .115, span = Math.sqrt(Math.max(0, 1 - Math.pow(row / .77, 2))) * 1.12;
          context.beginPath();
          for (let step = 0; step <= 95; step++) {
            const bx = -span + step / 95 * span * 2;
            const by = row + Math.sin(bx * 14 + band * 1.63 + time * .15) * .026 + Math.sin(bx * 26 - band) * .013;
            const px = centerX + bx * baseScale, py = centerY + by * baseScale;
            if (step === 0) context.moveTo(px, py); else context.lineTo(px, py);
          }
          context.lineWidth = .75; context.strokeStyle = band % 3 === 0 ? "#dfb976" : "#9276ee"; context.stroke();
        }
        context.globalAlpha = 1;
      }
      if (globeVisibility > .08) {
        const globeRadius = baseScale * 1.08;
        context.globalAlpha = globeVisibility * .13;
        context.strokeStyle = "#9c83ec"; context.lineWidth = .8;
        context.beginPath(); context.arc(centerX, centerY, globeRadius, 0, TAU); context.stroke();
        for (let band = -2; band <= 2; band++) {
          const latitude = band * .29, horizontal = Math.sqrt(1 - latitude * latitude) * globeRadius;
          context.beginPath(); context.ellipse(centerX, centerY + latitude * globeRadius, horizontal, Math.max(2, horizontal * .1), 0, 0, TAU); context.stroke();
        }
        for (let meridian = 1; meridian < 4; meridian++) {
          context.beginPath(); context.ellipse(centerX, centerY, globeRadius * meridian / 4, globeRadius, 0, 0, TAU); context.stroke();
        }
        context.globalAlpha = 1;
      }
      if (interior > .05) {
        context.lineWidth = .7;
        for (let index = 0; index < synapses.length; index++) {
          const first = synapses[index], second = synapses[(index + 5 + index % 4) % synapses.length];
          const drift = (time * .68 + position * 4 + first.z + 6) % 6, depth = 1 / (.32 + drift * .45);
          const ax = centerX + first.x * baseScale * depth, ay = centerY + first.y * baseScale * depth, bx = centerX + second.x * baseScale * depth * .89, by = centerY + second.y * baseScale * depth * .89;
          if (ax < -200 || ax > width + 200 || ay < -200 || ay > height + 200 || bx < -200 || bx > width + 200 || by < -200 || by > height + 200) continue;
          context.globalAlpha = interior * clamp(depth * .17, .035, .19); context.strokeStyle = first.color;
          context.beginPath(); context.moveTo(ax, ay); context.bezierCurveTo(ax + (bx - ax) * .26 - 24, ay + (by - ay) * .42 + 22, ax + (bx - ax) * .71 + 18, ay + (by - ay) * .67 - 18, bx, by); context.stroke();
          const signal = (time * .75 + first.phase) % 1;
          context.globalAlpha = interior * .7; context.fillStyle = first.color;
          context.beginPath(); context.arc(ax + (bx - ax) * signal, ay + (by - ay) * signal, 1.55, 0, TAU); context.fill();
        }
      }
      for (let index = 0; index < points.length; index++) {
        const point = points[index], rotation = time * .13 + smoothX * .14, cos = Math.cos(rotation), sin = Math.sin(rotation);
        const globeRotation = Math.sin(time * .11) * .16 - .09 + smoothX * .13, globeCos = Math.cos(globeRotation), globeSin = Math.sin(globeRotation);
        const brainX = point.x * cos - point.z * sin, brainZ = point.x * sin + point.z * cos;
        const globeX = point.globeX * globeCos - point.globeZ * globeSin, globeZ = point.globeX * globeSin + point.globeZ * globeCos;
        const assembledX = brainX * (1 - globeMix) + globeX * globeMix + point.scatterX * dissolve * .47;
        const assembledY = point.y * (1 - globeMix) + point.globeY * globeMix + point.scatterY * dissolve * .47;
        const assembledZ = brainZ * (1 - globeMix) + globeZ * globeMix + point.scatterZ * dissolve * .25;
        const flow = ((point.tunnelZ - position * 8 - time * .22 + 20) % 10) - 1, depth = 1 / (.28 + Math.max(.1, flow) * .32);
        const morphX = assembledX * (1 - interior) + point.tunnelX * depth * interior, morphY = assembledY * (1 - interior) + point.tunnelY * depth * interior;
        const perspective = 1 + assembledZ * .16 * (1 - interior), screenX = centerX + morphX * baseScale * perspective + smoothX * 16, screenY = centerY + morphY * baseScale * perspective + smoothY * 11;
        if (screenX < -16 || screenX > width + 16 || screenY < -16 || screenY > height + 16) continue;
        const pulse = Math.sin(time * 2 + point.phase) * .15 + .85, fade = interior > .1 ? clamp(depth * .63, .07, 1) : 1;
        const hemisphere = globeMix > .1 ? clamp(.17 + (globeZ + 1.08) * .38, .12, 1) : 1;
        const landContrast = globeVisibility > .12 && !point.land ? 1 - globeVisibility * .75 : 1;
        const continentBrightness = globeVisibility > .2 && point.land ? 1 + globeVisibility * .24 : 1;
        context.globalAlpha = clamp((.5 + (assembledZ + .74) * .29) * pulse * fade * hemisphere * landContrast * continentBrightness, 0, .97);
        const size = point.size * 1.12 * (1 + globeVisibility * (point.land ? .35 : -.12)) * (1 + interior * clamp(depth - .4, 0, 1));
        const particleColor = globeVisibility > .45 && !point.land ? "#605780" : globeVisibility > .45 && point.land && index % 7 === 0 ? "#f0cb77" : point.color;
        context.strokeStyle = particleColor; context.fillStyle = particleColor;
        if (point.outline && size > 1.15) { context.lineWidth = .72; context.beginPath(); context.moveTo(screenX, screenY - size * 1.45); context.lineTo(screenX - size * 1.25, screenY + size * .85); context.lineTo(screenX + size * 1.25, screenY + size * .85); context.closePath(); context.stroke(); }
        else { context.beginPath(); context.arc(screenX, screenY, size * .7, 0, TAU); context.fill(); }
      }
      if (interior > .1) for (const synapse of synapses) {
        const drift = (time * .68 + position * 4 + synapse.z + 6) % 6, depth = 1 / (.32 + drift * .45), x = centerX + synapse.x * baseScale * depth, y = centerY + synapse.y * baseScale * depth;
        if (x < -70 || x > width + 70 || y < -70 || y > height + 70) continue;
        const radius = synapse.radius * depth * (1 + Math.sin(time * 2 + synapse.phase) * .16), aura = context.createRadialGradient(x, y, 0, x, y, radius * 5);
        aura.addColorStop(0, synapse.color); aura.addColorStop(.13, `${synapse.color}aa`); aura.addColorStop(1, `${synapse.color}00`);
        context.globalAlpha = interior * clamp(depth * .46, .09, .72); context.fillStyle = aura; context.beginPath(); context.arc(x, y, radius * 5, 0, TAU); context.fill();
      }
      context.globalAlpha = 1; frame = window.requestAnimationFrame(render);
    };
    resize(); frame = window.requestAnimationFrame(render);
    window.addEventListener("resize", resize, { passive: true }); window.addEventListener("pointermove", move, { passive: true });
    return () => { window.cancelAnimationFrame(frame); window.removeEventListener("resize", resize); window.removeEventListener("pointermove", move); };
  }, [progress]);
  return <canvas ref={canvasRef} className="neural-canvas" aria-hidden="true" />;
}

export default function Home() {
  const progress = useRef(0), journeyRef = useRef<HTMLElement>(null);
  const [displayProgress, setDisplayProgress] = useState(0);
  const opacity = (start: number, end: number) => clamp(Math.min((displayProgress - start) / 9, (end - displayProgress) / 9));
  const jumpToStage = (stage: number) => {
    const journey = journeyRef.current;
    if (!journey) return;
    const top = journey.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({ top: top + Math.max(0, journey.offsetHeight - window.innerHeight) * stage, behavior: "smooth" });
  };
  useEffect(() => {
    let frame = 0, target = 0, lastDisplay = -1;
    const updateTarget = () => { const section = journeyRef.current; if (!section) return; const bounds = section.getBoundingClientRect(); target = clamp(-bounds.top / Math.max(1, bounds.height - window.innerHeight)); };
    const animate = () => { progress.current += (target - progress.current) * .075; const currentDisplay = Math.round(progress.current * 100); if (currentDisplay !== lastDisplay) { lastDisplay = currentDisplay; setDisplayProgress(currentDisplay); } frame = window.requestAnimationFrame(animate); };
    updateTarget(); frame = window.requestAnimationFrame(animate); window.addEventListener("scroll", updateTarget, { passive: true }); window.addEventListener("resize", updateTarget, { passive: true });
    return () => { window.cancelAnimationFrame(frame); window.removeEventListener("scroll", updateTarget); window.removeEventListener("resize", updateTarget); };
  }, []);
  return <main>
    <header className={`site-header ${displayProgress > 97 ? "site-header-solid" : ""}`}><a className="brand" href="#inicio" aria-label="LYXIA, inicio"><span className="brand-symbol" aria-hidden="true">◈</span>LYXIA</a><nav aria-label="Navegación principal"><a href="#vision">Visión</a><a href="#capacidades">Capacidades</a><a href="#contacto" className="header-cta">Hablemos <span>↗</span></a></nav></header>
    <section id="inicio" ref={journeyRef} className="journey" aria-label="Viaje inmersivo del cerebro al mundo y la expansión de la inteligencia"><div className="journey-sticky"><NeuralCanvas progress={progress} /><div className="journey-vignette" />
      <div className="chapter chapter-first" style={{ opacity: 1 - smoothstep(18, 34, displayProgress) }}><span className="eyebrow"><span /> Inteligencia aplicada · Valencia</span><h1>La inteligencia<br />que mueve<br /><span className="text-gradient">tu empresa.</span></h1><p>Convertimos procesos complejos en sistemas que piensan, aprenden y evolucionan contigo.</p><a className="inline-link" href="#vision">Descubre cómo <span>↗</span></a></div>
      <div className="chapter chapter-left chapter-world" style={{ opacity: opacity(30, 72), pointerEvents: "none" }}><span className="chapter-number">02 / UN MUNDO CONECTADO</span><h2>La inteligencia<br />que mueve<br /><span className="text-gold">el mundo.</span></h2><p>Conectamos ideas, datos y personas para transformar la forma en que las empresas avanzan.</p></div>
      <div className="chapter chapter-center" style={{ opacity: opacity(67, 109), pointerEvents: "none" }}><span className="chapter-number">03 / SIN LÍMITES</span><h2>La tecnología<br />que se adapta<br /><span className="text-gradient">a ti.</span></h2><p>Construimos inteligencia a medida, preparada para evolucionar al ritmo de tu empresa.</p></div>
      <div className="stage-navigation" aria-label="Etapas del recorrido">{[0, .49, .9].map((stage, index) => <button key={stage} type="button" aria-label={`Ir a la etapa ${index + 1}`} className={Math.abs(displayProgress / 100 - stage) < .22 ? "stage-active" : ""} onClick={() => jumpToStage(stage)} />)}</div>
      <div className="journey-bottom"><span className="scroll-prompt"><span /> Desliza para explorar</span><div className="progress-indicator"><span>{String(displayProgress).padStart(2, "0")}</span><i><b style={{ width: `${displayProgress}%` }} /></i><span>100</span></div><span className="system-status">SISTEMA ACTIVO <span /></span></div>
    </div></section>
    <section id="vision" className="vision-section"><div className="section-kicker"><span>01</span> NUESTRA VISIÓN</div><h2>El futuro no se predice.<br /><span>Se construye.</span></h2><p>No implementamos tecnología porque esté de moda. Diseñamos sistemas inteligentes que resuelven problemas reales, liberan tiempo y descubren oportunidades que antes eran invisibles.</p><div className="vision-metrics"><div><strong>100%</strong><span>Soluciones a medida</span></div><div><strong>∞</strong><span>Capacidad de evolución</span></div><div><strong>01</strong><span>Objetivo: tu crecimiento</span></div></div></section>
    <section id="capacidades" className="capabilities-section"><div className="section-kicker"><span>02</span> LO QUE HACEMOS</div><div className="section-heading"><h2>Tecnología con <span>propósito.</span></h2><p>Desde la primera línea de código hasta el último proceso optimizado.</p></div><div className="capability-grid"><article className="capability-card"><span className="card-icon">◈</span><span className="card-index">01</span><h3>Inteligencia artificial</h3><p>Modelos predictivos, redes neuronales y soluciones de IA entrenadas específicamente para tus necesidades.</p><span className="card-tag">MACHINE LEARNING · DEEP LEARNING</span></article><article className="capability-card"><span className="card-icon card-icon-gold">⌘</span><span className="card-index">02</span><h3>Automatización</h3><p>Procesos que antes consumían horas, ejecutados en segundos. Sin fricción y sin tareas repetitivas.</p><span className="card-tag">WORKFLOWS · INTEGRACIONES</span></article><article className="capability-card"><span className="card-icon card-icon-teal">◇</span><span className="card-index">03</span><h3>Software a medida</h3><p>Aplicaciones y plataformas diseñadas alrededor de cómo funciona realmente tu empresa.</p><span className="card-tag">FULL STACK · APIS · CLOUD</span></article><article className="capability-card"><span className="card-icon">⌁</span><span className="card-index">04</span><h3>Datos inteligentes</h3><p>Convertimos información dispersa en claridad operativa y decisiones respaldadas por evidencia.</p><span className="card-tag">DATA ENGINEERING · ANALYTICS</span></article></div></section>
    <section id="contacto" className="contact-section"><div className="contact-orb" aria-hidden="true" /><span className="section-kicker"><span>03</span> EMPECEMOS</span><h2>Tu próximo avance<br />empieza con una <span>conversación.</span></h2><p>Cuéntanos qué te gustaría transformar. Nosotros encontraremos la manera.</p><a className="contact-button" href="#inicio">Explorar de nuevo <span>↗</span></a></section>
    <footer className="site-footer"><a className="brand" href="#inicio"><span className="brand-symbol">◈</span>LYXIA</a><span>Inteligencia artificial con propósito.</span><span>VALENCIA · ESPAÑA</span></footer>
  </main>;
}
